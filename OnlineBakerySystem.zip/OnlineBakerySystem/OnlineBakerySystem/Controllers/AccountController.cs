﻿using Microsoft.AspNetCore.Mvc;
using OnlineBakerySystem.Models;

namespace OnlineBakerySystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly BakeryDbContext _context;

        public AccountController(BakeryDbContext context)
        {
            _context = context;
        }

        // Enter page
        public IActionResult Enter()
        {
            return View();
        }

        // ---------------- USER ----------------

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
            if (_context.Users.Any(u => u.Email == user.Email))
            {
                ViewBag.Error = "This email is already registered.";
                return View(user);
            }

            user.Role = "User";

            _context.Users.Add(user);
            _context.SaveChanges();

            return RedirectToAction("UserLogin");
        }

        public IActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserLogin(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(
                u => u.Email == email && u.Password == password);

            if (user == null)
            {
                ViewBag.Error = "Invalid email or password.";
                return View();
            }

            HttpContext.Session.SetString("UserId", user.Id.ToString());
            HttpContext.Session.SetString("UserName", user.Name);
            HttpContext.Session.SetString("Role", "User");

            return RedirectToAction("UserDashboard", "Home");
        }

        // ---------------- ADMIN ----------------

        public IActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AdminLogin(string email, string password)
        {
            if (email == "123israt@gmail.com" &&
      password == "123456")
            {
                HttpContext.Session.SetString("Role", "Admin");
                HttpContext.Session.SetString("UserName", "Admin");

                return RedirectToAction("Index", "Admin");
            }

            ViewBag.Error = "Invalid admin email or password.";

            return View();
        }

        // ---------------- LOGOUT ----------------

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Index", "Home");
        }
    }
}