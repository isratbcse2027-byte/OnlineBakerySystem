﻿using Microsoft.AspNetCore.Mvc;
using OnlineBakerySystem.Models;

namespace OnlineBakerySystem.Controllers
{
    public class OrderController : Controller
    {
        private readonly BakeryDbContext _context;

        public OrderController(BakeryDbContext context)
        {
            _context = context;
        }

        public IActionResult Cart(int id)
        {
            if (HttpContext.Session.GetString("Role") != "User")
            {
                return RedirectToAction("UserLogin", "Account");
            }

            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public IActionResult PlaceOrder(int productId, int quantity)
        {
            if (HttpContext.Session.GetString("Role") != "User")
            {
                return RedirectToAction("UserLogin", "Account");
            }

            var userId = HttpContext.Session.GetString("UserId");

            if (userId == null)
            {
                return RedirectToAction("UserLogin", "Account");
            }

            var product = _context.Products
                .FirstOrDefault(p => p.Id == productId);

            if (product == null)
            {
                return NotFound();
            }

            Order order = new Order
            {
                UserId = int.Parse(userId),
                ProductId = product.Id,
                Quantity = quantity,
                TotalPrice = product.Price * quantity,
                OrderDate = DateTime.Now,
                PaymentMethod = "Cash on Delivery"
            };

            _context.Orders.Add(order);
            _context.SaveChanges();

            return RedirectToAction("OrderSuccess");
        }

        public IActionResult Payment()
        {
            if (HttpContext.Session.GetString("Role") != "User")
            {
                return RedirectToAction("UserLogin", "Account");
            }

            return View();
        }

        public IActionResult Receipt()
        {
            if (HttpContext.Session.GetString("Role") != "User")
            {
                return RedirectToAction("UserLogin", "Account");
            }

            return View();
        }

        public IActionResult OrderSuccess()
        {
            return View();
        }

        public IActionResult MyOrders()
        {
            var userId = HttpContext.Session.GetString("UserId");

            if (userId == null)
            {
                return RedirectToAction("UserLogin", "Account");
            }

            var orders = _context.Orders
                .Where(o => o.UserId == int.Parse(userId))
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View(orders);
        }
    }
}