﻿using Microsoft.AspNetCore.Mvc;
using OnlineBakerySystem.Models;

namespace OnlineBakerySystem.Controllers
{
    public class ProductsController : Controller
    {
        private readonly BakeryDbContext _context;

        public ProductsController(BakeryDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products = _context.Products.ToList();

            return View(products);
        }

        public IActionResult Details(int id)
        {
            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // Add to Cart
        public IActionResult AddToCart(int id)
        {
            var role = HttpContext.Session.GetString("Role");

            if (role != "User")
            {
                return RedirectToAction("UserLogin", "Account");
            }

            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            return RedirectToAction("Cart", "Order", new { id = id });
        }
    }
}