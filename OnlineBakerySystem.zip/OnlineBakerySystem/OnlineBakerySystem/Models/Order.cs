﻿using System.ComponentModel.DataAnnotations;

namespace OnlineBakerySystem.Models
{
    public class Order
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public int ProductId { get; set; }

        public int Quantity { get; set; }

        public decimal TotalPrice { get; set; }

        public DateTime OrderDate { get; set; }

        public string PaymentMethod { get; set; } = "Cash on Delivery";
    }
}