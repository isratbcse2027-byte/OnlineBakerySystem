using Microsoft.EntityFrameworkCore;
using OnlineBakerySystem.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSession();

builder.Services.AddDbContext<BakeryDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("BakeryConnection")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

// Static files (CSS, JS, Images)
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");


// Sample products
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<BakeryDbContext>();

    if (!db.Products.Any())
    {
        db.Products.AddRange(
            new Product
            {
                Name = "Chocolate Cake",
                Category = "Cake",
                Price = 850,
                Description = "Soft and delicious chocolate cake.",
                ImageUrl = "/images/chocolate-cake.jpg"
            },

            new Product
            {
                Name = "Red Velvet Cake",
                Category = "Cake",
                Price = 950,
                Description = "Fresh red velvet cake with creamy frosting.",
                ImageUrl = "/images/red-velvet.jpg"
            },

            new Product
            {
                Name = "Vanilla Cake",
                Category = "Cake",
                Price = 750,
                Description = "Simple and tasty vanilla cake.",
                ImageUrl = "/images/vanilla-cake.jpg"
            },

            new Product
            {
                Name = "Butter Cookies",
                Category = "Biscuits",
                Price = 300,
                Description = "Crispy and buttery homemade cookies.",
                ImageUrl = "/images/butter-cookies.jpg"
            },

            new Product
            {
                Name = "Chocolate Cookies",
                Category = "Biscuits",
                Price = 350,
                Description = "Crunchy cookies filled with chocolate chips.",
                ImageUrl = "/images/chocolate-cookies.jpg"
            },

            new Product
            {
                Name = "Chocolate Brownie",
                Category = "Dessert",
                Price = 450,
                Description = "Rich and soft chocolate brownie.",
                ImageUrl = "/images/brownie.jpg"
            },

            new Product
            {
                Name = "Cheesecake",
                Category = "Dessert",
                Price = 600,
                Description = "Creamy cheesecake with a delicious topping.",
                ImageUrl = "/images/cheesecake.jpg"
            },

            new Product
            {
                Name = "Chocolate Donut",
                Category = "Dessert",
                Price = 180,
                Description = "Fresh donut covered with chocolate.",
                ImageUrl = "/images/donut.jpg"
            }
        );

        db.SaveChanges();
    }
}

app.Run();