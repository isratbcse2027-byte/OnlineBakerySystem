using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OnlineBakerySystem.Views.Admin
{
    public class OrdersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
