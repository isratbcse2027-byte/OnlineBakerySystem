using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OnlineBakerySystem.Views.Home
{
    public class UserDashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
